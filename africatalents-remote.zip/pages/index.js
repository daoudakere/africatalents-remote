export default function HomePage() {
  return (
    <main className="min-h-screen bg-white text-gray-800 p-6">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-blue-600 mb-2">AFRICATALENTS REMOTE</h1>
        <p className="text-lg">Connecting African Talents to Global Remote Opportunities</p>
      </header>

      <section className="grid md:grid-cols-2 gap-8 mb-12">
        <div>
          <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
          <p>
            We empower African professionals by bridging the gap between local talent and global remote work opportunities.
            Our goal is to make remote work accessible, reliable, and rewarding for qualified individuals across the continent.
          </p>
        </div>
        <div>
          <h2 className="text-2xl font-semibold mb-4">What We Offer</h2>
          <ul className="list-disc list-inside">
            <li>Verified remote job listings</li>
            <li>Personalized career coaching</li>
            <li>Soft skills & language training</li>
            <li>Employer matchmaking services</li>
          </ul>
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 text-center">For Talents</h2>
        <p className="text-center max-w-2xl mx-auto">
          Whether you're a developer, virtual assistant, customer service agent, or designer, we help you access well-paid, remote positions with reputable global companies. Join our community and unlock your potential.
        </p>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 text-center">For Employers</h2>
        <p className="text-center max-w-2xl mx-auto">
          Looking to hire remote talent? We connect you with pre-vetted professionals ready to contribute to your business success. Reduce hiring costs while maintaining top quality.
        </p>
      </section>

      <section className="text-center">
        <h2 className="text-2xl font-semibold mb-4">Get in Touch</h2>
        <p className="mb-2">Email: africatalents.remote@gmail.com</p>
        <p>LinkedIn: linkedin.com/in/africatalents-remote</p>
      </section>
    </main>
  );
}